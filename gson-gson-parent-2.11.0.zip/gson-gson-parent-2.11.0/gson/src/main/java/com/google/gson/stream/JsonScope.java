/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

/**
 * Lexical scoping elements within a JSON reader or writer.
 *
 * @author Jesse Wilson
 * @since 1.6
 */
final class JsonScope {
  private JsonScope() {}

  /** An array with no elements requires no separator before the next element. */
  static final int EMPTY_ARRAY = 1;

  /** An array with at least one value requires a separator before the next element. */
  static final int NONEMPTY_ARRAY = 2;

  /** An object with no name/value pairs requires no separator before the next element. */
  static final int EMPTY_OBJECT = 3;

  /** An object whose most recent element is a key. The next element must be a value. */
  static final int DANGLING_NAME = 4;

  /** An object with at least one name/value pair requires a separator before the next element. */
  static final int NONEMPTY_OBJECT = 5;

  /** No top-level value has been started yet. */
  static final int EMPTY_DOCUMENT = 6;

  /** A top-level value has already been started. */
  static final int NONEMPTY_DOCUMENT = 7;

  /** A document that's been closed and cannot be accessed. */
  static final int CLOSED = 8;
}
